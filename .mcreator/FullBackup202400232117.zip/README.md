# Astolfo Forge Mod

## Feature list:

- Femboy Biome (Astolfo biome in ID's)
- Astolfo in 4 outfits
- Astolfo flower, which spawns a lot of Astolfo when destroyed
- Felix
- Astolfo Sword
- Hideri
- Venti
- Rimuru
- Nagisa
- Sieg
- Bridget 🏳️‍⚧️
- /duplicate_cuties command for more cuteness <3
- /despawn command for debug purposes
- /cuterain command for cute rain :3

## Features added in 1.2

- Added Hideri
- Added Bridget
- Added Venti
- Added /cuterain
- Added /despawn
- Added /duplicatecuties
- Added Rimuru
- Added Nagisa
- Added Sieg

# Building from Source

1. Clone this project
2. Download MCreator
3. Open "astolfo.mcreator" using MCreator
4. The program should perform the build automatically
5. Test things by clicking the play button in the right top corner
6. Click export in the right top corner and save the JAR file somewhere on your disk
7. Done